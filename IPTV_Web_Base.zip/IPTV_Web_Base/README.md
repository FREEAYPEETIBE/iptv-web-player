# IPTV Web Base (Netflix-Style)

A responsive, Netflix-style IPTV web app that supports live TV streaming via M3U playlists with proxy integration for secure playback. Designed for both **desktop** and **mobile browsers**.

## Features

- **Fixed top video player** with autoplay
- **Netflix-style UI** for channels (horizontal sliders per category)
- **Channel categories** (group-title support)
- **Search bar**
- **Dark/Light mode toggle**
- **Split-screen preview (optional)**
- **Supports `.m3u`, `.m3u8`, `.ts`, `.mpd` sources**
- **Auto-detects if proxy backend is needed**
- Works with **header-protected streams** via Render proxy
- Fully **static**, can be hosted on GitHub Pages or any static server

## Folder Structure

```
IPTV_Web_Base/
├── index.html
├── assets/
│   ├── css/
│   ├── js/
│   └── logos/
├── playlists/
│   └── processed.m3u
├── README.md
```

## Proxy Backend

This setup uses a proxy for channels requiring headers (e.g., Referer, User-Agent). Update `config.js` to use your own Render URL:

```js
const PROXY_BASE_URL = 'https://iptv-proxy-fgpp.onrender.com';
```

## Deploying Locally

1. Unzip the package.
2. Open `index.html` in any modern browser.
3. Done!

## Deploying Online

You can upload the entire folder to:
- GitHub Pages
- Netlify (drag-and-drop)
- Vercel (static export)
- Any web host that supports static HTML
