
document.addEventListener('DOMContentLoaded', () => {
  const video = document.getElementById('videoPlayer');
  const searchInput = document.getElementById('search');
  const channelList = document.getElementById('channelList');

  fetch('playlists/processed.m3u')
    .then(response => response.text())
    .then(text => {
      const lines = text.split('\n');
      let channels = [];
      for (let i = 0; i < lines.length; i++) {
        if (lines[i].startsWith('#EXTINF')) {
          const title = lines[i].split(',').pop();
          const url = lines[i + 1];
          channels.push({ title, url });
        }
      }

      function renderChannels(filtered = channels) {
        channelList.innerHTML = '';
        filtered.forEach(ch => {
          const div = document.createElement('div');
          div.textContent = ch.title;
          div.style.cursor = 'pointer';
          div.onclick = () => video.src = ch.url;
          channelList.appendChild(div);
        });
      }

      renderChannels();
      searchInput.addEventListener('input', () => {
        const val = searchInput.value.toLowerCase();
        const filtered = channels.filter(c => c.title.toLowerCase().includes(val));
        renderChannels(filtered);
      });
    });
});
